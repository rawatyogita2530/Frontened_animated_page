import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Preloader({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0);
  const [exit, setExit] = useState(false);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setCount(100);
      setExit(true);
      const t = setTimeout(onDone, 200);
      return () => clearTimeout(t);
    }

    let raf: number;
    const start = performance.now();
    const DURATION = 1500;

    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / DURATION);
      const eased = 1 - Math.pow(1 - p, 3);
      setCount(Math.round(eased * 100));
      if (p < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        setTimeout(() => setExit(true), 250);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <AnimatePresence onExitComplete={onDone}>
      {!exit && (
        <motion.div
          className="fixed inset-0 z-[500] flex flex-col items-center justify-center bg-ink"
          exit={{ clipPath: "inset(0 0 100% 0)" }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
        >
          <div className="flex items-center gap-3 text-phosphor">
            <svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true">
              <circle cx="7" cy="7" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
              <circle cx="17" cy="17" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
              <line x1="9.3" y1="9.3" x2="14.7" y2="14.7" stroke="currentColor" strokeWidth="1.4" />
            </svg>
            <span className="font-mono text-xs tracking-[0.2em] text-text-dim">ASSEMBLING PLATFORM</span>
          </div>
          <div className="mt-8 font-display text-[clamp(3.5rem,14vw,9rem)] leading-none text-text tabular-nums">
            {count}
            <span className="text-phosphor">%</span>
          </div>
          <div className="mt-6 h-px w-48 bg-white/10 overflow-hidden">
            <motion.div
              className="h-full bg-phosphor"
              style={{ width: `${count}%` }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
