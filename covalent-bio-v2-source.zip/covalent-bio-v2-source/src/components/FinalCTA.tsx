import { useState, Suspense, lazy } from "react";
import { motion } from "framer-motion";
import Magnetic from "./Magnetic";

const Blob = lazy(() => import("../three/Blob"));

export default function FinalCTA() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative overflow-hidden border-t border-white/[0.06] px-5 py-28 sm:px-8 lg:py-36">
      <div className="pointer-events-none absolute -right-32 top-1/2 hidden h-[640px] w-[640px] -translate-y-1/2 opacity-60 md:block">
        <Suspense fallback={null}>
          <Blob className="h-full w-full" />
        </Suspense>
      </div>

      <div className="relative mx-auto max-w-[780px]">
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.7 }}
          className="eyebrow text-phosphor"
        >
          Specimen 05 — Next step
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8, delay: 0.05 }}
          className="mt-4 text-[clamp(2.1rem,5vw,3.6rem)] leading-[1.12] text-text"
        >
          Bring us a target. <br className="hidden md:inline" />
          We'll bring you a molecule.
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="mt-5 max-w-[60ch] text-[1.05rem] leading-[1.7] text-text-dim"
        >
          Most engagements start with a 30-minute technical briefing — no deck, just your
          target and our platform's read on it.
        </motion.p>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
          className="mt-11 flex max-w-[520px] flex-wrap gap-3"
        >
          <label htmlFor="email" className="sr-only">
            Work email
          </label>
          <input
            id="email"
            type="email"
            required
            placeholder="you@yourbiotech.com"
            autoComplete="email"
            className="min-w-[220px] flex-1 rounded-full border border-white/15 bg-transparent px-5 py-3.5 text-[14.5px] text-text placeholder:text-text-dim focus:border-phosphor focus:outline-none"
          />
          <Magnetic>
            <button
              type="submit"
              data-cursor="hover"
              className="group inline-flex items-center gap-2 rounded-full bg-phosphor px-6 py-3.5 text-[14.5px] font-medium text-ink transition-colors hover:bg-white"
            >
              Request a briefing
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-transform group-hover:translate-x-1">
                <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </Magnetic>
        </motion.form>
        <p role="status" aria-live="polite" className="mt-4 min-h-[16px] font-mono text-[12.5px] text-phosphor">
          {sent ? "Thanks — our team will reach out within one business day." : "\u00A0"}
        </p>
      </div>
    </section>
  );
}
