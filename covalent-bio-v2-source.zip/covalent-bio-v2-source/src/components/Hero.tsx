import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Magnetic from "./Magnetic";
import DNAHelix from "../three/DNAHelix";
import ScrambleText from "./ScrambleText";

gsap.registerPlugin(ScrollTrigger);

const LINES = ["We design", "proteins the way", "engineers design bridges."];

export default function Hero() {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasWrapRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "expo.out" }, delay: 0.1 });
      tl.to(".hero-eyebrow", { opacity: 1, y: 0, duration: 0.7 }, 0)
        .to(".hero-line span", { yPercent: 0, duration: 1.1, stagger: 0.1 }, 0.1)
        .to(".hero-sub", { opacity: 1, y: 0, duration: 0.8 }, 0.55)
        .to(".hero-actions", { opacity: 1, y: 0, duration: 0.8 }, 0.68)
        .to(".hero-cue", { opacity: 1, duration: 0.8 }, 0.9)
        .to(".hero-canvas-wrap", { opacity: 1, duration: 1.4 }, 0.2);

      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reduced) {
        // Scroll-driven "flythrough": camera dollies into the helix and the
        // whole scene fades as the reader leaves the hero for the next section.
        ScrollTrigger.create({
          trigger: rootRef.current,
          start: "top top",
          end: "bottom top",
          scrub: 0.4,
          onUpdate: (self) => {
            progressRef.current = self.progress;
          },
        });
        gsap.to(canvasWrapRef.current, {
          opacity: 0,
          ease: "none",
          scrollTrigger: {
            trigger: rootRef.current,
            start: "60% top",
            end: "bottom top",
            scrub: 0.4,
          },
        });
      }
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={rootRef} id="top" className="relative flex min-h-[100svh] items-center overflow-hidden px-5 pt-36 pb-20 sm:px-8">
      <div
        ref={canvasWrapRef}
        className="hero-canvas-wrap pointer-events-none absolute inset-0 z-0 opacity-0 [mask-image:radial-gradient(ellipse_at_60%_45%,black_65%,transparent_92%)]"
      >
        <DNAHelix className="h-full w-full" progressRef={progressRef} />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-[1240px]">
        <div className="max-w-[840px]">
          <p className="hero-eyebrow eyebrow mb-6 flex translate-y-3 items-center gap-2 text-phosphor opacity-0">
            <span className="h-1.5 w-1.5 rounded-full bg-phosphor shadow-[0_0_12px_#79FFE1]" />
            <ScrambleText text="Programmable protein therapeutics" delay={550} />
          </p>

          <h1 className="text-[clamp(2.6rem,6.4vw,5.4rem)] leading-[1.03] text-text">
            {LINES.map((line, i) => (
              <span key={i} className="reveal-mask">
                <span
                  className={`hero-line block translate-y-[110%] ${i === 2 ? "italic text-phosphor" : ""}`}
                >
                  {line}
                </span>
              </span>
            ))}
          </h1>

          <p className="hero-sub mt-7 max-w-[52ch] translate-y-3 text-lg leading-relaxed text-text-dim opacity-0">
            Covalent Bio's computational platform turns a disease target into a folded,
            manufacturable molecule — compressing years of wet-lab guesswork into weeks
            of directed design.
          </p>

          <div className="hero-actions mt-10 flex translate-y-3 flex-wrap gap-4 opacity-0">
            <Magnetic>
              <a
                href="#technology"
                data-cursor="hover"
                className="group inline-flex items-center gap-2 rounded-full bg-phosphor px-6 py-3.5 text-[14.5px] font-medium text-ink transition-colors hover:bg-white"
              >
                See the platform
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-transform group-hover:translate-x-1">
                  <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            </Magnetic>
            <Magnetic>
              <a
                href="#contact"
                data-cursor="hover"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3.5 text-[14.5px] font-medium text-text transition-colors hover:border-phosphor hover:text-phosphor"
              >
                Request a briefing
              </a>
            </Magnetic>
          </div>

          <div className="hero-cue mt-16 flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.12em] text-text-dim opacity-0">
            <span>Scroll</span>
            <span className="relative h-8 w-px overflow-hidden bg-white/10">
              <span className="absolute inset-x-0 top-0 h-full w-full animate-[scrollcue_2.2s_ease-in-out_infinite] bg-gradient-to-b from-phosphor to-transparent" />
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scrollcue {
          0%, 100% { transform: translateY(-100%); }
          50% { transform: translateY(100%); }
        }
      `}</style>
    </section>
  );
}
