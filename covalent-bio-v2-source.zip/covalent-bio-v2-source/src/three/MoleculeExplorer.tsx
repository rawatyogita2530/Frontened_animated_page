import { useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Html } from "@react-three/drei";
import * as THREE from "three";

type Atom = { pos: THREE.Vector3; kind: "core" | "phosphor" | "amber" };

// Deterministic pseudo-random cluster of bonded atoms — reads as a small
// folded protein domain rather than a generic sphere pile.
function useMolecule() {
  return useMemo(() => {
    const atoms: Atom[] = [];
    const seedPositions: [number, number, number, Atom["kind"]][] = [
      [0, 0, 0, "core"],
      [0.9, 0.4, 0.2, "core"],
      [1.6, 1.1, -0.3, "core"],
      [1.2, 2.0, 0.5, "phosphor"],
      [0.2, 2.3, 1.1, "core"],
      [-0.7, 1.7, 0.6, "core"],
      [-1.1, 0.8, -0.2, "core"],
      [-0.5, -0.6, 0.4, "core"],
      [0.4, -1.2, -0.3, "amber"],
      [1.3, -0.8, 0.6, "core"],
      [-1.6, -0.2, 1.0, "core"],
      [-2.1, 0.9, 0.2, "amber"],
      [2.3, 0.3, 0.9, "core"],
      [0.6, 1.1, -1.2, "phosphor"],
    ];
    seedPositions.forEach(([x, y, z, kind]) => atoms.push({ pos: new THREE.Vector3(x, y, z), kind }));

    const bonds: [number, number][] = [];
    const maxDist = 1.7;
    for (let i = 0; i < atoms.length; i++) {
      for (let j = i + 1; j < atoms.length; j++) {
        if (atoms[i].pos.distanceTo(atoms[j].pos) < maxDist) bonds.push([i, j]);
      }
    }
    return { atoms, bonds };
  }, []);
}

const COLORS: Record<Atom["kind"], string> = {
  core: "#E9F3EF",
  phosphor: "#79FFE1",
  amber: "#FF9C4A",
};

function Atoms({ atoms }: { atoms: Atom[] }) {
  return (
    <>
      {atoms.map((a, i) => (
        <mesh key={i} position={a.pos}>
          <sphereGeometry args={[a.kind === "core" ? 0.16 : 0.22, 20, 20]} />
          <meshStandardMaterial
            color={COLORS[a.kind]}
            emissive={COLORS[a.kind]}
            emissiveIntensity={a.kind === "core" ? 0.15 : 0.55}
            roughness={0.3}
            metalness={0.1}
          />
        </mesh>
      ))}
    </>
  );
}

function Bonds({ atoms, bonds }: { atoms: Atom[]; bonds: [number, number][] }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame(() => {
    const mesh = meshRef.current;
    if (!mesh || mesh.userData.placed) return;
    bonds.forEach(([ia, ib], i) => {
      const p1 = atoms[ia].pos;
      const p2 = atoms[ib].pos;
      const mid = p1.clone().add(p2).multiplyScalar(0.5);
      const dist = p1.distanceTo(p2);
      dummy.position.copy(mid);
      dummy.scale.set(1, dist, 1);
      dummy.lookAt(p2);
      dummy.rotateX(Math.PI / 2);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.userData.placed = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, bonds.length]}>
      <cylinderGeometry args={[0.035, 0.035, 1, 8]} />
      <meshStandardMaterial color="#9FB5AE" transparent opacity={0.5} />
    </instancedMesh>
  );
}

const HOTSPOTS = [
  { atomIndex: 3, label: "Engineered binding loop" },
  { atomIndex: 8, label: "Catalytic residue" },
  { atomIndex: 11, label: "Stability mutation" },
];

function Hotspots({ atoms }: { atoms: Atom[] }) {
  const [active, setActive] = useState<number | null>(null);
  return (
    <>
      {HOTSPOTS.map((h) => {
        const pos = atoms[h.atomIndex].pos;
        return (
          <Html key={h.atomIndex} position={pos} center distanceFactor={7} occlude style={{ pointerEvents: "auto" }}>
            <button
              data-cursor="hover"
              onMouseEnter={() => setActive(h.atomIndex)}
              onMouseLeave={() => setActive(null)}
              onClick={() => setActive((cur) => (cur === h.atomIndex ? null : h.atomIndex))}
              className="group relative flex items-center"
            >
              <span className="block h-2.5 w-2.5 rounded-full bg-phosphor shadow-[0_0_10px_#79FFE1]" />
              <span
                className={`ml-3 whitespace-nowrap rounded-full border border-white/15 bg-ink/90 px-3 py-1.5 font-mono text-[11px] text-text backdrop-blur transition-all duration-200 ${
                  active === h.atomIndex ? "opacity-100 translate-x-0" : "pointer-events-none -translate-x-1 opacity-0"
                }`}
              >
                {h.label}
              </span>
            </button>
          </Html>
        );
      })}
    </>
  );
}

function Scene() {
  const { atoms, bonds } = useMolecule();
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.05;
  });

  return (
    <group ref={group}>
      <group position={[0, -0.6, 0]}>
        <Atoms atoms={atoms} />
        <Bonds atoms={atoms} bonds={bonds} />
        <Hotspots atoms={atoms} />
      </group>
    </group>
  );
}

export default function MoleculeExplorer({ className = "" }: { className?: string }) {
  return (
    <Canvas className={className} dpr={[1, 1.75]} camera={{ position: [0, 0.5, 6.5], fov: 40 }}>
      <ambientLight intensity={0.55} />
      <pointLight position={[4, 4, 5]} intensity={35} color="#79FFE1" />
      <pointLight position={[-4, -2, 3]} intensity={18} color="#FF9C4A" />
      <Scene />
      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={4}
        maxDistance={9}
        autoRotate
        autoRotateSpeed={0.6}
        enableDamping
        dampingFactor={0.08}
      />
    </Canvas>
  );
}
