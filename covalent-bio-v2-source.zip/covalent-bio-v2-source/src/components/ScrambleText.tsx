import { useEffect, useRef } from "react";

const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01#$%&+=?";

/**
 * Scrambles the element's own text content into place — characters cycle
 * through a random glyph set before resolving to the real letter, left to
 * right. Triggers once when the element enters the viewport.
 */
export function useScrambleReveal(ref: React.RefObject<HTMLElement | null>, options?: { delay?: number }) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const finalText = el.textContent || "";
    if (reduced || !finalText) return;

    let started = false;
    let raf = 0;

    const run = () => {
      if (started) return;
      started = true;
      const duration = 900;
      const start = performance.now() + (options?.delay ?? 0);

      const frame = (now: number) => {
        const elapsed = now - start;
        if (elapsed < 0) {
          raf = requestAnimationFrame(frame);
          return;
        }
        const progress = Math.min(1, elapsed / duration);
        const revealCount = Math.floor(progress * finalText.length);
        let out = "";
        for (let i = 0; i < finalText.length; i++) {
          const ch = finalText[i];
          if (ch === " ") { out += " "; continue; }
          if (i < revealCount) out += ch;
          else out += CHARS[Math.floor(Math.random() * CHARS.length)];
        }
        el.textContent = out;
        if (progress < 1) raf = requestAnimationFrame(frame);
        else el.textContent = finalText;
      };
      raf = requestAnimationFrame(frame);
    };

    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && run()),
      { threshold: 0.4 }
    );
    observer.observe(el);

    return () => {
      observer.disconnect();
      cancelAnimationFrame(raf);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

export default function ScrambleText({
  text,
  as: Tag = "span",
  className = "",
  delay = 0,
}: {
  text: string;
  as?: keyof React.JSX.IntrinsicElements;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLElement>(null);
  useScrambleReveal(ref as React.RefObject<HTMLElement | null>, { delay });
  return (
    // @ts-expect-error dynamic tag
    <Tag ref={ref} className={className}>
      {text}
    </Tag>
  );
}
