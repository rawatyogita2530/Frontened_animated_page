import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import StageCanvas from "./StageCanvas";
import ScrambleText from "./ScrambleText";

gsap.registerPlugin(ScrollTrigger);

const STAGES = [
  {
    num: "01",
    shape: "target" as const,
    title: "Target mapping",
    body: "We build a structural map of the disease target — every binding pocket, every conformational state — from cryo-EM and sequence data.",
  },
  {
    num: "02",
    shape: "fold" as const,
    title: "Generative folding",
    body: "Our fold-prediction models propose thousands of candidate sequences and score each on stability, binding affinity, and immunogenicity risk.",
  },
  {
    num: "03",
    shape: "bind" as const,
    title: "Binding simulation",
    body: "Top candidates are docked in silico against the target and off-target panels, ranking real binding behavior before synthesis.",
  },
  {
    num: "04",
    shape: "assemble" as const,
    title: "Wet-lab validation",
    body: "Only validated designs reach the bench, where our lab confirms fold, function, and manufacturability — closing the loop back into the model.",
  },
];

export default function Pipeline() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const section = sectionRef.current;
    const track = trackRef.current;
    if (!section || !track || reduced) return;

    const ctx = gsap.context(() => {
      const panels = gsap.utils.toArray<HTMLElement>(".stage-panel");
      const distance = track.scrollWidth - section.clientWidth;

      const tween = gsap.to(track, {
        x: () => -distance,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${distance + window.innerHeight * 0.6}`,
          scrub: 0.7,
          pin: true,
          anticipatePin: 1,
        },
      });

      panels.forEach((panel) => {
        gsap.fromTo(
          panel.querySelector(".panel-content"),
          { opacity: 0.25, y: 24 },
          {
            opacity: 1,
            y: 0,
            ease: "power2.out",
            scrollTrigger: {
              trigger: panel,
              containerAnimation: tween,
              start: "left 70%",
              end: "left 30%",
              scrub: true,
            },
          }
        );
      });

      gsap.to(".pipeline-progress-fill", {
        scaleX: 1,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${distance + window.innerHeight * 0.6}`,
          scrub: 0.5,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section id="technology" ref={sectionRef} className="relative overflow-hidden bg-ink-soft">
      <div className="absolute inset-x-0 top-0 z-10 px-5 pt-24 sm:px-8">
        <div className="mx-auto max-w-[1240px]">
          <p className="eyebrow text-phosphor"><ScrambleText text="Specimen 02 — Platform" /></p>
          <h2 className="mt-4 max-w-[26ch] text-[clamp(1.9rem,4vw,3rem)] leading-[1.14] text-text">
            One pipeline, from target to therapeutic.
          </h2>
          <div className="mt-6 h-px w-40 origin-left scale-x-0 bg-gradient-to-r from-phosphor to-amber pipeline-progress-fill" />
        </div>
      </div>

      <div ref={trackRef} className="flex h-screen w-max items-center pl-5 pt-16 sm:pl-8">
        {STAGES.map((s) => (
          <article key={s.num} className="stage-panel flex h-full w-[86vw] shrink-0 items-center pr-10 sm:w-[52vw] lg:w-[38vw]">
            <div className="panel-content grid gap-8">
              <div className="aspect-square w-full max-w-[280px] overflow-hidden rounded-3xl border border-white/[0.08] bg-panel">
                <StageCanvas shape={s.shape} className="h-full w-full" />
              </div>
              <div>
                <p className="font-mono text-[13px] text-amber">{s.num}</p>
                <h3 className="mt-2 text-2xl text-text">{s.title}</h3>
                <p className="mt-3 max-w-[42ch] text-[0.98rem] leading-[1.65] text-text-dim">{s.body}</p>
              </div>
            </div>
          </article>
        ))}
        <div className="w-[10vw] shrink-0" />
      </div>
    </section>
  );
}
