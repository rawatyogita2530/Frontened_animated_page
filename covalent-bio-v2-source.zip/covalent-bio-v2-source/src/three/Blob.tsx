import { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { MeshDistortMaterial, Sphere } from "@react-three/drei";
import * as THREE from "three";

function AnimatedBlob() {
  const meshRef = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.y = state.clock.elapsedTime * 0.08;
    meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.15) * 0.2;
  });
  return (
    <Sphere ref={meshRef} args={[1.8, 96, 96]}>
      <MeshDistortMaterial
        color="#12211D"
        emissive="#79FFE1"
        emissiveIntensity={0.18}
        roughness={0.25}
        metalness={0.1}
        distort={0.45}
        speed={1.4}
      />
    </Sphere>
  );
}

export default function Blob({ className = "" }: { className?: string }) {
  return (
    <Canvas className={className} dpr={[1, 1.5]} camera={{ position: [0, 0, 5.5], fov: 45 }}>
      <ambientLight intensity={0.4} />
      <pointLight position={[3, 2, 4]} intensity={30} color="#79FFE1" />
      <pointLight position={[-3, -2, 2]} intensity={18} color="#FF9C4A" />
      <AnimatedBlob />
    </Canvas>
  );
}
