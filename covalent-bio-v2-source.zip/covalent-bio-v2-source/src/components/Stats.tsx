import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ScrambleText from "./ScrambleText";

gsap.registerPlugin(ScrollTrigger);

const STATS = [
  { value: 18, decimals: 0, suffix: "mo", label: "average target-to-candidate time, down from 4–5 years industry median" },
  { value: 240, decimals: 0, suffix: "+", label: "de novo binders generated and validated since 2022" },
  { value: 6, decimals: 0, suffix: "", label: "partner programs currently in IND-enabling studies" },
  { value: 99.2, decimals: 1, suffix: "%", label: "predicted-to-observed fold correlation on held-out targets" },
];

export default function Stats() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>(".stat-item").forEach((el, i) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 24 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            delay: (i % 4) * 0.08,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 90%" },
          }
        );
      });

      gsap.utils.toArray<HTMLElement>(".stat-num").forEach((el) => {
        const target = Number(el.dataset.target);
        const decimals = Number(el.dataset.decimals || 0);
        const suffix = el.dataset.suffix || "";
        const obj = { val: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 90%",
          once: true,
          onEnter: () =>
            gsap.to(obj, {
              val: target,
              duration: 1.6,
              ease: "power2.out",
              onUpdate: () => {
                el.textContent = obj.val.toFixed(decimals) + suffix;
              },
            }),
        });
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={rootRef} id="impact" className="bg-paper px-5 py-28 text-paper-text sm:px-8 lg:py-36">
      <div className="mx-auto max-w-[1240px]">
        <p className="eyebrow text-[#0F6B58]"><ScrambleText text="Specimen 04 — Impact" /></p>
        <h2 className="mt-4 max-w-[24ch] text-[clamp(1.9rem,4vw,3rem)] leading-[1.14] text-paper-text">
          Numbers from the bench, not the pitch deck.
        </h2>

        <div className="mt-16 grid grid-cols-1 gap-px border-y border-black/10 bg-black/10 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="stat-item bg-paper px-6 pb-3 pt-9">
              <p className="font-display text-[clamp(2.4rem,4vw,3.4rem)] leading-none text-paper-text">
                <span className="stat-num" data-target={s.value} data-decimals={s.decimals} data-suffix={s.suffix}>
                  0
                </span>
              </p>
              <p className="mt-3.5 max-w-[22ch] text-[12.5px] leading-snug text-paper-text-dim">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
