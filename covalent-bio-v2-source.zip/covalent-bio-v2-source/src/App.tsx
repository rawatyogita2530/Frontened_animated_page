import { useState } from "react";
import Preloader from "./components/Preloader";
import CustomCursor from "./components/CustomCursor";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Pipeline from "./components/Pipeline";
import Explore from "./components/Explore";
import Capabilities from "./components/Capabilities";
import Stats from "./components/Stats";
import FinalCTA from "./components/FinalCTA";
import Footer from "./components/Footer";
import { useSmoothScroll } from "./hooks/useSmoothScroll";

export default function App() {
  const [loaded, setLoaded] = useState(false);
  useSmoothScroll();

  return (
    <>
      <div className="grain" aria-hidden="true" />
      <Preloader onDone={() => setLoaded(true)} />
      <CustomCursor />
      <a
        href="#main"
        className="fixed left-4 top-4 z-[400] -translate-y-24 rounded-full bg-phosphor px-4 py-2 text-sm text-ink focus:translate-y-0"
      >
        Skip to content
      </a>

      <Navbar />
      <main id="main" style={{ visibility: loaded ? "visible" : "hidden" }}>
        <Hero />
        <About />
        <Pipeline />
        <Explore />
        <Capabilities />
        <Stats />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
