import { useMemo, useRef, type RefObject, type MutableRefObject } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import ShaderField from "./ShaderField";

const TURNS = 5.5;
const NODES_PER_STRAND = 60;
const RADIUS = 1.5;
const HEIGHT = 9;

function useHelixPoints(offset: number) {
  return useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i < NODES_PER_STRAND; i++) {
      const t = i / (NODES_PER_STRAND - 1);
      const angle = t * Math.PI * 2 * TURNS + offset;
      pts.push(
        new THREE.Vector3(
          Math.cos(angle) * RADIUS,
          t * HEIGHT - HEIGHT / 2,
          Math.sin(angle) * RADIUS
        )
      );
    }
    return pts;
  }, [offset]);
}

function Strand({ offset, color }: { offset: number; color: string }) {
  const pointsA = useHelixPoints(offset);
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  return (
    <>
      <instancedMesh ref={meshRef} args={[undefined, undefined, pointsA.length]}>
        <sphereGeometry args={[0.075, 12, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.65} roughness={0.35} />
        <Positioner points={pointsA} target={meshRef} dummy={dummy} />
      </instancedMesh>
      <Ribbon points={pointsA} color={color} />
    </>
  );
}

// Sets instance matrices once points are known (runs during render via a side-effect component)
function Positioner({
  points,
  target,
  dummy,
}: {
  points: THREE.Vector3[];
  target: RefObject<THREE.InstancedMesh | null>;
  dummy: THREE.Object3D;
}) {
  useFrame(() => {
    const mesh = target.current;
    if (!mesh || mesh.userData.placed) return;
    points.forEach((p, i) => {
      dummy.position.copy(p);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.userData.placed = true;
  });
  return null;
}

function Ribbon({ points, color }: { points: THREE.Vector3[]; color: string }) {
  const curve = useMemo(() => new THREE.CatmullRomCurve3(points), [points]);
  const geometry = useMemo(() => new THREE.TubeGeometry(curve, 120, 0.022, 6, false), [curve]);
  return (
    <mesh geometry={geometry}>
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.35} transparent opacity={0.55} />
    </mesh>
  );
}

function Rungs() {
  const a = useHelixPoints(0);
  const b = useHelixPoints(Math.PI);
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const count = a.length;

  useFrame(() => {
    const mesh = meshRef.current;
    if (!mesh || mesh.userData.placed) return;
    for (let i = 0; i < count; i++) {
      const p1 = a[i];
      const p2 = b[i];
      const mid = p1.clone().add(p2).multiplyScalar(0.5);
      const dist = p1.distanceTo(p2);
      dummy.position.copy(mid);
      dummy.scale.set(1, dist, 1);
      dummy.lookAt(p2);
      dummy.rotateX(Math.PI / 2);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.userData.placed = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <cylinderGeometry args={[0.012, 0.012, 1, 6]} />
      <meshStandardMaterial color="#E9F3EF" transparent opacity={0.18} />
    </instancedMesh>
  );
}

function Rig({ progressRef }: { progressRef: MutableRefObject<number> }) {
  const group = useRef<THREE.Group>(null);
  const { pointer, camera } = useThree();

  useFrame((_, delta) => {
    if (!group.current) return;
    const p = progressRef.current; // 0 -> 1 as the user scrolls through the hero/pipeline arc
    const speedBoost = 1 + p * 2.4;
    group.current.rotation.y += delta * 0.18 * speedBoost;
    const targetX = pointer.y * 0.25;
    const targetZ = -pointer.x * 0.2;
    group.current.rotation.x += (targetX - group.current.rotation.x) * 0.04;
    group.current.rotation.z += (targetZ - group.current.rotation.z) * 0.04;

    // Dolly the camera "into" the strand as progress increases — a flythrough.
    const targetZPos = 8.5 - p * 5.4;
    camera.position.z += (targetZPos - camera.position.z) * 0.06;
    const targetFov = 42 + p * 18;
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov += (targetFov - camera.fov) * 0.06;
      camera.updateProjectionMatrix();
    }
  });

  return (
    <group ref={group} rotation={[0.15, 0, 0]}>
      <Strand offset={0} color="#79FFE1" />
      <Strand offset={Math.PI} color="#FF9C4A" />
      <Rungs />
    </group>
  );
}

export default function DNAHelix({
  className = "",
  progressRef,
}: {
  className?: string;
  progressRef?: MutableRefObject<number>;
}) {
  const fallbackRef = useRef(0);
  const ref = progressRef ?? fallbackRef;

  return (
    <Canvas
      className={className}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
      camera={{ position: [0, 0, 8.5], fov: 42 }}
    >
      <ambientLight intensity={0.5} />
      <pointLight position={[4, 4, 6]} intensity={40} color="#79FFE1" />
      <pointLight position={[-4, -3, 4]} intensity={24} color="#FF9C4A" />
      <ShaderField position={[0, 0, -4]} />
      <Rig progressRef={ref} />
    </Canvas>
  );
}
