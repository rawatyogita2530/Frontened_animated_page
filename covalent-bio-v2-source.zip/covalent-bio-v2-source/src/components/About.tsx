import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ScrambleText from "./ScrambleText";

gsap.registerPlugin(ScrollTrigger);

const FACTS = [
  { value: 1200, suffix: "", label: "sequences designed in silico / week" },
  { value: 94, suffix: "%", label: "reduction in wet-lab screening cycles" },
  { value: 11, suffix: "", label: "therapeutic programs in active design" },
];

export default function About() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>(".fade-up").forEach((el) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 85%" },
          }
        );
      });

      gsap.utils.toArray<HTMLElement>(".count-num").forEach((el) => {
        const target = Number(el.dataset.target);
        const obj = { val: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 88%",
          once: true,
          onEnter: () => {
            gsap.to(obj, {
              val: target,
              duration: 1.6,
              ease: "power2.out",
              onUpdate: () => {
                el.textContent = Math.round(obj.val).toLocaleString();
              },
            });
          },
        });
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={rootRef} id="innovation" className="border-t border-white/[0.06] px-5 py-28 sm:px-8 lg:py-36">
      <div className="mx-auto grid max-w-[1240px] gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        <div className="fade-up">
          <p className="eyebrow mb-5 text-phosphor"><ScrambleText text="Specimen 01 — Approach" /></p>
          <h2 className="max-w-[18ch] text-[clamp(1.9rem,4vw,3rem)] leading-[1.14] text-text">
            Biology has always been programmable.{" "}
            <span className="text-text-dim">We just didn't have the compiler.</span>
          </h2>
        </div>

        <div>
          <p className="fade-up max-w-[52ch] text-[1.05rem] leading-[1.7] text-text-dim">
            Every therapeutic is a molecule that has to fold correctly, bind precisely, and
            survive the body long enough to work. For sixty years that meant screening
            thousands of candidates by hand and hoping one behaved.
          </p>
          <p className="fade-up mt-5 max-w-[52ch] text-[1.05rem] leading-[1.7] text-text-dim">
            Covalent Bio replaces the hoping with modeling. Our platform simulates how a
            protein sequence will fold, bind, and degrade before it's ever synthesized — so
            the lab tests candidates that are already likely to work.
          </p>

          <ul className="mt-14 flex flex-wrap gap-10">
            {FACTS.map((f) => (
              <li key={f.label} className="fade-up flex min-w-[120px] flex-col">
                <span className="font-display text-[2.6rem] leading-none text-phosphor">
                  <span className="count-num" data-target={f.value}>
                    0
                  </span>
                  {f.suffix}
                </span>
                <span className="mt-2.5 max-w-[16ch] text-[12.5px] leading-snug text-text-dim">
                  {f.label}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
