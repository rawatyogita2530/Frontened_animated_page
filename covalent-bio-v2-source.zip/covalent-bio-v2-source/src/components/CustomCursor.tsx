import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

const TRAIL = [
  { stiffness: 500, damping: 30, size: 8, opacity: 0.9 },
  { stiffness: 280, damping: 28, size: 6, opacity: 0.5 },
  { stiffness: 160, damping: 26, size: 5, opacity: 0.3 },
];

export default function CustomCursor() {
  const [ready, setReady] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [visible, setVisible] = useState(true);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const springX = useSpring(x, { damping: 28, stiffness: 340, mass: 0.4 });
  const springY = useSpring(y, { damping: 28, stiffness: 340, mass: 0.4 });
  const isCoarse = useRef(false);

  useEffect(() => {
    isCoarse.current = window.matchMedia("(hover: none)").matches;
    if (isCoarse.current) return;
    setReady(true);

    const move = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      const target = e.target as HTMLElement;
      setHovering(!!target.closest('[data-cursor="hover"]'));
    };
    const leave = () => setVisible(false);
    const enter = () => setVisible(true);

    window.addEventListener("pointermove", move);
    document.addEventListener("mouseleave", leave);
    document.addEventListener("mouseenter", enter);
    return () => {
      window.removeEventListener("pointermove", move);
      document.removeEventListener("mouseleave", leave);
      document.removeEventListener("mouseenter", enter);
    };
  }, [x, y]);

  if (!ready) return null;

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[300]"
      animate={{ opacity: visible ? 1 : 0 }}
    >
      {TRAIL.map((t, i) => (
        <TrailDot key={i} x={x} y={y} {...t} />
      ))}
      <motion.div
        className="pointer-events-none fixed left-0 top-0 mix-blend-difference"
        style={{ x: springX, y: springY, translateX: "-50%", translateY: "-50%" }}
      >
        <motion.div
          className="rounded-full bg-phosphor"
          animate={{ width: hovering ? 56 : 10, height: hovering ? 56 : 10 }}
          transition={{ type: "spring", damping: 22, stiffness: 320 }}
        />
      </motion.div>
    </motion.div>
  );
}

function TrailDot({
  x,
  y,
  stiffness,
  damping,
  size,
  opacity,
}: {
  x: ReturnType<typeof useMotionValue<number>>;
  y: ReturnType<typeof useMotionValue<number>>;
  stiffness: number;
  damping: number;
  size: number;
  opacity: number;
}) {
  const sx = useSpring(x, { stiffness, damping, mass: 0.6 });
  const sy = useSpring(y, { stiffness, damping, mass: 0.6 });
  return (
    <motion.div
      className="pointer-events-none fixed left-0 top-0 rounded-full bg-phosphor"
      style={{
        x: sx,
        y: sy,
        width: size,
        height: size,
        opacity,
        translateX: "-50%",
        translateY: "-50%",
      }}
    />
  );
}
