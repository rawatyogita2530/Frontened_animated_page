export default function Footer() {
  return (
    <footer className="border-t border-white/[0.06] bg-ink-soft px-5 py-12 sm:px-8">
      <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-5">
        <a href="#top" data-cursor="hover" className="flex items-center gap-2 text-text">
          <svg viewBox="0 0 24 24" width="20" height="20" className="text-phosphor">
            <circle cx="7" cy="7" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <circle cx="17" cy="17" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <line x1="9.3" y1="9.3" x2="14.7" y2="14.7" stroke="currentColor" strokeWidth="1.4" />
          </svg>
          <span className="font-mono text-[13px] tracking-[0.08em]">
            COVALENT<span className="ml-1 opacity-50">BIO</span>
          </span>
        </a>
        <p className="text-[12.5px] text-text-dim">© 2026 Covalent Bio, Inc. Cambridge, MA.</p>
        <div className="flex gap-6 text-[13px] text-text-dim">
          <a href="#innovation" data-cursor="hover" className="hover:text-phosphor">Approach</a>
          <a href="#technology" data-cursor="hover" className="hover:text-phosphor">Platform</a>
          <a href="#capabilities" data-cursor="hover" className="hover:text-phosphor">Capabilities</a>
          <a href="#contact" data-cursor="hover" className="hover:text-phosphor">Contact</a>
        </div>
      </div>
    </footer>
  );
}
