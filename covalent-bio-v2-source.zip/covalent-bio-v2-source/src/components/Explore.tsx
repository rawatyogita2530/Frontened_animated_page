import { lazy, Suspense } from "react";
import { motion } from "framer-motion";

const MoleculeExplorer = lazy(() => import("../three/MoleculeExplorer"));

export default function Explore() {
  return (
    <section id="explore" className="relative border-t border-white/[0.06] bg-ink px-5 py-28 sm:px-8 lg:py-36">
      <div className="mx-auto grid max-w-[1240px] items-center gap-14 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7 }}
            className="eyebrow text-phosphor"
          >
            Specimen 03.5 — Live model
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, delay: 0.05 }}
            className="mt-4 max-w-[18ch] text-[clamp(1.9rem,4vw,3rem)] leading-[1.14] text-text"
          >
            This is a real output. Drag it.
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="mt-5 max-w-[46ch] text-[1.02rem] leading-[1.7] text-text-dim"
          >
            A simplified render of one of our engineered binding domains.
            Rotate it, zoom in, and hover the marked residues to see what the
            platform actually changed — and why.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-8 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.12em] text-text-dim"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-amber" />
            Drag to rotate · scroll to zoom · hover a residue
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.9, ease: [0.16, 0.84, 0.32, 1] }}
          className="relative aspect-square w-full overflow-hidden rounded-[28px] border border-white/[0.08] bg-panel"
        >
          <Suspense
            fallback={
              <div className="flex h-full w-full items-center justify-center font-mono text-xs text-text-dim">
                Loading model…
              </div>
            }
          >
            <MoleculeExplorer className="h-full w-full cursor-grab active:cursor-grabbing" />
          </Suspense>
        </motion.div>
      </div>
    </section>
  );
}
