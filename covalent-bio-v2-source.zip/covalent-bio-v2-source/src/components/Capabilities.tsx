import { useRef, type MouseEvent } from "react";
import { motion, useMotionTemplate, useMotionValue, useSpring } from "framer-motion";
import ScrambleText from "./ScrambleText";

const ITEMS = [
  {
    title: "De novo protein design",
    body: "Generate entirely new binding proteins for targets with no known natural ligand.",
    path: "M16 3v26M6 9c3 3 3 7 0 10M26 9c-3 3-3 7 0 10",
  },
  {
    title: "Structure prediction",
    body: "Fold thousands of candidate sequences in parallel and rank by predicted stability.",
    path: "M16 16m-5 0a5 5 0 1 0 10 0a5 5 0 1 0 -10 0",
  },
  {
    title: "Binding affinity modeling",
    body: "Score candidate–target interactions against off-target panels before synthesis.",
    path: "M4 22c6 0 6-14 12-14s6 14 12 14",
  },
  {
    title: "Manufacturability scoring",
    body: "Flag designs that fold beautifully in silico but resist real-world expression, early.",
    path: "M5 5h9v9h-9zM18 18h9v9h-9zM14 9h9v9",
  },
  {
    title: "Wet-lab validation loop",
    body: "In-house expression and assay data feed straight back into the model, weekly.",
    path: "M6 16h6l3-9 4 18 3-9h4",
  },
  {
    title: "Program partnership",
    body: "We co-develop programs end-to-end with partner biotechs, from target to IND.",
    path: "M16 4l3.6 7.4L28 12.6l-6 5.9 1.4 8.3L16 22.9l-7.4 3.9L10 18.5l-6-5.9 8.4-1.2z",
  },
];

function TiltCard({ title, body, path }: (typeof ITEMS)[number]) {
  const ref = useRef<HTMLDivElement>(null);
  const rotX = useMotionValue(0);
  const rotY = useMotionValue(0);
  const springX = useSpring(rotX, { stiffness: 220, damping: 20 });
  const springY = useSpring(rotY, { stiffness: 220, damping: 20 });
  const mx = useMotionValue(50);
  const my = useMotionValue(50);
  const spotlight = useMotionTemplate`radial-gradient(240px circle at ${mx}% ${my}%, rgba(121,255,225,0.12), transparent 70%)`;

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    rotY.set((px - 0.5) * 14);
    rotX.set((0.5 - py) * 14);
    mx.set(px * 100);
    my.set(py * 100);
  };

  const handleLeave = () => {
    rotX.set(0);
    rotY.set(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      data-cursor="hover"
      style={{ rotateX: springX, rotateY: springY, transformPerspective: 800 }}
      className="group relative overflow-hidden border border-white/[0.06] bg-ink-soft p-9 transition-colors duration-300 hover:bg-panel"
    >
      <motion.div className="pointer-events-none absolute inset-0" style={{ backgroundImage: spotlight }} />
      <div className="relative">
        <svg viewBox="0 0 32 32" width="26" height="26" className="text-phosphor">
          <path d={path} fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
        </svg>
        <h3 className="mt-6 text-[1.15rem] text-text">{title}</h3>
        <p className="mt-2.5 text-[0.95rem] leading-relaxed text-text-dim">{body}</p>
      </div>
    </motion.div>
  );
}

export default function Capabilities() {
  return (
    <section id="capabilities" className="px-5 py-28 sm:px-8 lg:py-36">
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-16 max-w-[640px]">
          <p className="eyebrow text-phosphor"><ScrambleText text="Specimen 03 — Capabilities" /></p>
          <h2 className="mt-4 text-[clamp(1.9rem,4vw,3rem)] leading-[1.14] text-text">
            What the platform is built to do.
          </h2>
        </div>
        <div className="grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-white/[0.06] bg-white/[0.06] sm:grid-cols-2 lg:grid-cols-3">
          {ITEMS.map((item) => (
            <TiltCard key={item.title} {...item} />
          ))}
        </div>
      </div>
    </section>
  );
}
