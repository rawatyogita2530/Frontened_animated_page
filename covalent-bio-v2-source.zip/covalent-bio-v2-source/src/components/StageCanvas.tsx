import { useEffect, useRef } from "react";

type Shape = "target" | "fold" | "bind" | "assemble";

export default function StageCanvas({ shape, className = "" }: { shape: Shape; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let w = 0,
      h = 0,
      dpr = 1,
      t = Math.random() * 100,
      raf = 0;

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas!.clientWidth;
      h = canvas!.clientHeight;
      canvas!.width = w * dpr;
      canvas!.height = h * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function drawTarget() {
      const cx = w / 2,
        cy = h / 2,
        base = Math.min(w, h) * 0.32;
      ctx!.clearRect(0, 0, w, h);
      for (let i = 3; i >= 1; i--) {
        ctx!.beginPath();
        ctx!.arc(cx, cy, base * (i / 3) + Math.sin(t / 40 + i) * 3, 0, Math.PI * 2);
        ctx!.strokeStyle = i === 1 ? "#FF9C4A" : "rgba(121,255,225,0.35)";
        ctx!.lineWidth = i === 1 ? 2 : 1;
        ctx!.stroke();
      }
      ctx!.beginPath();
      ctx!.arc(cx, cy, 3.2, 0, Math.PI * 2);
      ctx!.fillStyle = "#FF9C4A";
      ctx!.fill();
    }

    function drawFold() {
      ctx!.clearRect(0, 0, w, h);
      const cx = w / 2,
        cy = h / 2,
        amp = Math.min(w, h) * 0.26;
      ctx!.beginPath();
      for (let i = 0; i <= 60; i++) {
        const p = i / 60;
        const x = cx + Math.sin(p * Math.PI * 4 + t / 30) * amp * (0.4 + 0.6 * p);
        const y = cy - amp + p * amp * 2;
        if (i === 0) ctx!.moveTo(x, y);
        else ctx!.lineTo(x, y);
      }
      ctx!.strokeStyle = "#79FFE1";
      ctx!.lineWidth = 2;
      ctx!.stroke();
    }

    function drawBind() {
      ctx!.clearRect(0, 0, w, h);
      const cx = w / 2,
        cy = h / 2,
        r = Math.min(w, h) * 0.22;
      const wobble = Math.sin(t / 25) * 6;
      ctx!.beginPath();
      ctx!.arc(cx - r * 0.5 - wobble, cy, r * 0.55, 0, Math.PI * 2);
      ctx!.strokeStyle = "rgba(121,255,225,0.7)";
      ctx!.lineWidth = 1.6;
      ctx!.stroke();
      ctx!.beginPath();
      ctx!.arc(cx + r * 0.5 + wobble, cy, r * 0.4, 0, Math.PI * 2);
      ctx!.strokeStyle = "#FF9C4A";
      ctx!.lineWidth = 1.6;
      ctx!.stroke();
      ctx!.beginPath();
      ctx!.moveTo(cx - r * 0.1 - wobble, cy);
      ctx!.lineTo(cx + r * 0.15 + wobble, cy);
      ctx!.strokeStyle = "rgba(233,243,239,0.5)";
      ctx!.setLineDash([2, 3]);
      ctx!.stroke();
      ctx!.setLineDash([]);
    }

    function drawAssemble() {
      ctx!.clearRect(0, 0, w, h);
      const cx = w / 2,
        cy = h / 2,
        n = 6,
        r = Math.min(w, h) * 0.26;
      const pts: [number, number][] = [];
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + t / 60;
        pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
      }
      ctx!.beginPath();
      pts.forEach((p, i) => (i === 0 ? ctx!.moveTo(p[0], p[1]) : ctx!.lineTo(p[0], p[1])));
      ctx!.closePath();
      ctx!.strokeStyle = "#79FFE1";
      ctx!.lineWidth = 1.4;
      ctx!.stroke();
      pts.forEach((p, i) => {
        ctx!.beginPath();
        ctx!.arc(p[0], p[1], 3, 0, Math.PI * 2);
        ctx!.fillStyle = i % 2 === 0 ? "#FF9C4A" : "#79FFE1";
        ctx!.fill();
      });
    }

    const drawers: Record<Shape, () => void> = {
      target: drawTarget,
      fold: drawFold,
      bind: drawBind,
      assemble: drawAssemble,
    };
    const draw = drawers[shape];

    function loop() {
      t += 1;
      draw();
      if (!reduced) raf = requestAnimationFrame(loop);
    }

    resize();
    draw();
    const onResize = () => {
      resize();
      draw();
    };
    window.addEventListener("resize", onResize);
    if (!reduced) raf = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener("resize", onResize);
      cancelAnimationFrame(raf);
    };
  }, [shape]);

  return <canvas ref={canvasRef} className={className} />;
}
