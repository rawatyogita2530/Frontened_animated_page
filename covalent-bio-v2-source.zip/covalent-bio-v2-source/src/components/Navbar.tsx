import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Magnetic from "./Magnetic";

const LINKS = [
  { href: "#innovation", label: "Approach" },
  { href: "#technology", label: "Platform" },
  { href: "#explore", label: "Model" },
  { href: "#capabilities", label: "Capabilities" },
  { href: "#impact", label: "Impact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-100 transition-colors duration-500 ${
        scrolled ? "backdrop-blur-xl bg-ink/70 border-b border-white/[0.06]" : ""
      }`}
    >
      <div className="mx-auto flex max-w-[1240px] items-center justify-between px-5 py-4 sm:px-8">
        <a href="#top" data-cursor="hover" className="flex items-center gap-2 text-text">
          <svg viewBox="0 0 24 24" width="20" height="20" className="text-phosphor">
            <circle cx="7" cy="7" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <circle cx="17" cy="17" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <line x1="9.3" y1="9.3" x2="14.7" y2="14.7" stroke="currentColor" strokeWidth="1.4" />
          </svg>
          <span className="font-mono text-[13px] tracking-[0.08em]">
            COVALENT<span className="ml-1 opacity-50">BIO</span>
          </span>
        </a>

        <nav className="hidden gap-8 text-sm text-text-dim md:flex" aria-label="Primary">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} data-cursor="hover" className="group relative py-1">
              {l.label}
              <span className="absolute inset-x-0 -bottom-0.5 h-px origin-left scale-x-0 bg-phosphor transition-transform duration-300 group-hover:scale-x-100" />
            </a>
          ))}
        </nav>

        <Magnetic className="hidden md:block">
          <a
            href="#contact"
            className="rounded-full border border-white/15 px-4 py-2 font-mono text-[13px] transition-colors hover:border-phosphor hover:bg-phosphor/10"
          >
            Partner with us
          </a>
        </Magnetic>

        <button
          className="flex flex-col gap-1.5 p-2 md:hidden"
          aria-label="Open menu"
          aria-expanded={open}
          data-cursor="hover"
          onClick={() => setOpen((o) => !o)}
        >
          <motion.span animate={{ rotate: open ? 45 : 0, y: open ? 6 : 0 }} className="block h-px w-5 bg-text" />
          <motion.span animate={{ opacity: open ? 0 : 1 }} className="block h-px w-5 bg-text" />
          <motion.span animate={{ rotate: open ? -45 : 0, y: open ? -6 : 0 }} className="block h-px w-5 bg-text" />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.35, ease: [0.76, 0, 0.24, 1] }}
            className="overflow-hidden border-t border-white/10 bg-ink-soft md:hidden"
          >
            <div className="flex flex-col px-5 py-4">
              {LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="border-b border-white/5 py-4 text-base"
                >
                  {l.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="mt-4 rounded-full bg-phosphor px-4 py-3 text-center font-mono text-[13px] text-ink"
              >
                Partner with us
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
